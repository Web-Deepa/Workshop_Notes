name = input("Enter Your Name: ")
print("Hello,", name, "Welcome to Python Programming!")

# name = input("Enter Your Name: ")
# print(f"Hello, {name}! Welcome to Python Programming!")
# # Using f-string for formatted output


